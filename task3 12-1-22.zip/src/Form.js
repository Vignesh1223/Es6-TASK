import React from 'react';
import {useState} from 'react'

function Data()
{
  const [UserMailId,setUserMailId]=useState("");
  const [Password,setPassword]=useState("");
  const [name,setName]=useState("");
  const [Mobile,setMobile]=useState("");
  const [CB,setCB]=useState(false);
  const [dropdown,setDropdown] =useState("");


  function handleData(event)
  {
    event.preventDefault()
    console.log("USERMAILID:",UserMailId)
    console.log("PASSWORD:",Password)
    console.log("NAME:",name)
    console.log("MOBILE:",Mobile)
    console.log("All data: ",UserMailId,Password,name,Mobile,CB)
    
  
}
  return(
  <div>

    <form onSubmit={handleData}>

    <h2>UserMail Id :</h2>
   <input type="text" placeholder="Enter Mail Id" onChange={(event)=>setUserMailId(event.target.value)} />

   <h2>Password:</h2>
   <input type="Password" placeholder="Enter Password" onChange={(event)=>setPassword(event.target.value)}/>

   <h2>Name :</h2>
   <input name="text" placeholder="Enter Name" onChange={(event)=>setName(event.target.value)} />

   <h2>Mobile :</h2>
   <input number="text" placeholder="Enter Mobile" onChange={(event)=>setMobile(event.target.value)}/><br></br><br></br>

   <input type="checkbox"  onChange={(event)=>setCB(event.target.value)}/><span> Agree With Term And Conditions</span><br></br><br></br>

   
   <button type="Display"><h1>Register </h1></button>

     <h1>Buy your Product : {dropdown}</h1>
      <select value={dropdown}
        onchange={(e) => {
          setDropdown(e.target.value)
        }}>
        <option value="Bike">Bike</option>
        <option value="car">Car</option>
        <option value="Bus">Bus</option>
      </select>
  

   </form>
   </div>
   );

}

export default Data;