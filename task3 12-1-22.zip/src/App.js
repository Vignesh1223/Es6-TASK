
import React from 'react';
import "./style.css";
import Data from './Form.js';

function App() {
  return (
    <div>
      <Data />
      

    </div>);
}
export default App; 